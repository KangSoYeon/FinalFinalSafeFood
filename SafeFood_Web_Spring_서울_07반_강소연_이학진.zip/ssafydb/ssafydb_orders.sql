-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafydb
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `orders` (
  `ono` int(11) NOT NULL AUTO_INCREMENT,
  `odate` datetime DEFAULT CURRENT_TIMESTAMP,
  `id` varchar(30) COLLATE utf8_bin DEFAULT NULL,
  `gno` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `address` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`ono`),
  KEY `fk_orders_id` (`id`),
  KEY `fk_orders_gno` (`gno`),
  CONSTRAINT `fk_orders_gno` FOREIGN KEY (`gno`) REFERENCES `goods` (`gno`),
  CONSTRAINT `fk_orders_id` FOREIGN KEY (`id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'2018-08-18 00:00:00','ssafy',2,1,'나주'),(2,'2018-08-18 00:00:00','jaen',4,2,'서울'),(3,'2018-01-11 00:00:00','ssafy',4,2,'서울'),(4,'2018-01-15 00:00:00','ssafy',1,20,'서울'),(5,'2018-01-30 00:00:00','jaen',2,20,'서울'),(6,'2018-01-31 00:00:00','ssafy',3,100,'나주'),(7,'2018-02-12 00:00:00','jaen',4,10,'나주'),(8,'2018-03-22 00:00:00','jaen',4,10,'서울'),(9,'2019-05-13 13:57:20','ssafy',1,40,'서울'),(10,'2019-06-13 13:57:20','jaen',4,2,'서울'),(11,'2019-06-13 13:57:20','jaen',2,2,'서울'),(12,'2019-07-13 13:57:20','ssafy',1,1,'서울'),(13,'2019-07-13 13:57:20','ssafy',2,2,'서울'),(14,'2019-08-13 13:57:20','jaen',1,1,'서울'),(15,'2019-08-13 13:57:20','ssafy',2,2,'서울');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-24 20:00:54
