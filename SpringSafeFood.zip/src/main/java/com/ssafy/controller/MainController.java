package com.ssafy.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.cache.CacheException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.model.dto.Member;
import com.ssafy.model.dto.MemberException;
import com.ssafy.model.dto.MyDiet;
import com.ssafy.model.dto.PageBean;
import com.ssafy.model.dto.TotalDiet;
import com.ssafy.model.service.MemberService;
import com.ssafy.model.service.MyDietService;
import com.ssafy.util.PageUtility;
import com.ssafy.model.dto.Cart;
import com.ssafy.model.dto.Food;
import com.ssafy.model.dto.FoodException;
import com.ssafy.model.service.CartService;
import com.ssafy.model.service.FoodService;

/**
 * Servlet implementation class MainServlet
 */
@Controller
public class MainController {
	@Autowired
	private MemberService memberService;
	@Autowired
	private FoodService foodService;
	@Autowired
	private MyDietService mydietService;
	@Autowired
	private CartService cartService;
	

	@ExceptionHandler
	public ModelAndView handle(Exception e) {
		e.printStackTrace();
		ModelAndView mav = new ModelAndView("ErrorHandler");
		return mav;
	}
	
	@GetMapping("detailform.do")
	public String detailform(HttpServletRequest request) {
		String code = request.getParameter("code");
		String msg = request.getParameter("msg");
		Food food = foodService.search(code);
		request.setAttribute("food", food);
		request.setAttribute("msg",msg);
		if(getId(request)!=null) {
			String id = getId(request);
			Member member = memberService.search(id);
			request.setAttribute("member", member);
		}
		return "detail";
	}
	@GetMapping("loginform.do")
	public String loginform() {
		return "login";
	}
	
	@GetMapping("signUpform.do")
	public String signUpform() {
		return "signUp";
	}
	
	// 관리자 전용 상품 추가 폼 이동
	@GetMapping("addfoodform.do")
	public String addfoodform(HttpServletRequest request) {
		List<Food> list = foodService.searchAll();
		int size = list.size();
		request.setAttribute("code", size+1);
		String msg = request.getParameter("msg");
		System.out.println("메시지 : "+msg);
		request.setAttribute("msg", msg);
		return "addfood";
	}
	
	// 관리자 전용 상품 수정 폼 이동
	@GetMapping("modifyform.do")
	public String modifyform(HttpServletRequest request){
		String code = request.getParameter("code");
		Food food = foodService.search(code);
		request.setAttribute("food", food);
		return "modify_food";
	}
	
	@PostMapping("modify.do")
	public String modify(HttpServletRequest request,Food food) {
		System.out.println(food.toString());
		try {
			String dir = request.getRealPath("/");
			food.setDir(dir);
//			if(food.getFileup()==null)
			foodService.update(food);
			return "redirect:index.do";
		} catch (Exception e) {
			e.printStackTrace();
			String msg="";
			try {
				msg = URLEncoder.encode(e.getMessage(), "UTF-8");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			return "redirect:modifyform.do?code="+food.getCode()+"msg="+msg;
		}
	}
	
	// 상품 추가 기능
	@PostMapping("addfood.do")
	public String addfood(Food food, HttpServletRequest request) {
		try {
			String dir = request.getRealPath("/");
			food.setDir(dir);
			foodService.insert(food);
			return "redirect:index.do";
		} catch (Exception e) {
			e.printStackTrace();
			String msg="";
			try {
				msg = URLEncoder.encode(e.getMessage(), "UTF-8");
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			return "redirect:addfoodform.do?msg="+msg;
		}
	}
	
	// 상품 삭제 기능
	@PostMapping("deletefood.do")
	public String delfood(HttpServletRequest request) {
		String code = request.getParameter("Fcode");
		foodService.delete(code);
		return "redirect:index.do";
	}
	
	//회원 정보 창
	@GetMapping("meminfo.do")
	public String memInfo(HttpServletRequest request) {
		String id = getId(request);
		
		Member mem = memberService.search(id);
		request.setAttribute("member", mem);
		return "memberInfo";
	}

	// 비밀번호 찾기 폼 이동
	@GetMapping("findpasswordForm.do")
	public String findpasswordForm() {
		return "findPassword";
	}

	// 회원 삭제 기능
	@PostMapping("delete.do")
	private String delete(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("mem_id");
		memberService.delete(id);
		HttpSession session = request.getSession();
		session.invalidate();
		return "redirect:main.jsp";
	}
	
	// 회원 정보 수정 기능
	@PostMapping("update.do")
	private String update(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("mem_id");
		String pw = request.getParameter("mem_pw");
		String name = request.getParameter("mem_name");
		String email = request.getParameter("mem_email");
		String address = request.getParameter("mem_address");
		String phone = request.getParameter("mem_phone");
		int du = request.getParameter("mem_du") == null ? 0 : 1;
		int cong = request.getParameter("mem_cong") == null ? 0 : 1;
		int milk = request.getParameter("mem_milk") == null ? 0 : 1;
		int crab = request.getParameter("mem_crab") == null ? 0 : 1;
		int shi = request.getParameter("mem_shi") == null ? 0 : 1;
		int tu = request.getParameter("mem_tu") == null ? 0 : 1;
		int sal = request.getParameter("mem_sal") == null ? 0 : 1;
		int suk = request.getParameter("mem_suk") == null ? 0 : 1;
		int cow = request.getParameter("mem_cow") == null ? 0 : 1;
		int chi = request.getParameter("mem_chi") == null ? 0 : 1;
		int pig = request.getParameter("mem_pig") == null ? 0 : 1;
		int peach = request.getParameter("mem_peach") == null ? 0 : 1;
		int mind = request.getParameter("mem_mind") == null ? 0 : 1;
		int egg = request.getParameter("mem_egg") == null ? 0 : 1;

		Member member = new Member(id, pw, name, email, address, phone, du, cong, milk, crab, shi, tu, sal, suk, cow,
				chi, pig, peach, mind, egg);
		memberService.update(member);
		String pid = getId(request);
		request.setAttribute("member", memberService.search(pid));
		return "redirect:index.do";
	}

	@PostMapping("sign.do")
	private String sign(HttpServletRequest request, HttpServletResponse response) {

		String id = request.getParameter("id");
		String pw = request.getParameter("password");
		if(id==null) {
			throw new MemberException("아이디를 입력해주세요");
		}
		if(pw==null) {
			throw new MemberException("비밀번호를 입력해주세요");
		}
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		int du = request.getParameter("du") == null ? 0 : 1;
		int cong = request.getParameter("cong") == null ? 0 : 1;
		int milk = request.getParameter("milk") == null ? 0 : 1;
		int crab = request.getParameter("crab") == null ? 0 : 1;
		int shi = request.getParameter("shi") == null ? 0 : 1;
		int tu = request.getParameter("tu") == null ? 0 : 1;
		int sal = request.getParameter("sal") == null ? 0 : 1;
		int suk = request.getParameter("suk") == null ? 0 : 1;
		int cow = request.getParameter("cow") == null ? 0 : 1;
		int chi = request.getParameter("chi") == null ? 0 : 1;
		int pig = request.getParameter("pig") == null ? 0 : 1;
		int peach = request.getParameter("peach") == null ? 0 : 1;
		int mind = request.getParameter("mind") == null ? 0 : 1;
		int egg = request.getParameter("egg") == null ? 0 : 1;

		Member member = new Member(id, pw, name, email, address, phone, du, cong, milk, crab, shi, tu, sal, suk, cow,
				chi, pig, peach, mind, egg);
		try {
			memberService.insert(member);
			return "redirect:index.do";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", e.getMessage());
			return "signUpform.do";
		}
		
	}
	
	// 로그아웃 기능 ( 세션 저장 값 초기화 )
	@GetMapping("logout.do")
	private String logout(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "redirect:index.do";
	}
	
	// QnA 게시판 이동 폼
	@GetMapping("qna.do")
	private String qna() {
		return "QnA";
	}
	
	// 공지사항 게시판 이동 폼
	@GetMapping("notice.do")
	private String notice() {
		return "notice";
	}
	
	// 찜으로 추가된 예상 섭취 정보 삭제 기능
	@GetMapping("deletecart.do")
	private String deletecart(HttpServletRequest request) {
		int pageno = Integer.parseInt(request.getParameter("pageNumber"));
		int cno  = Integer.parseInt(request.getParameter("cno"));
		String day = request.getParameter("day");
		String msg = "";
		try {
			cartService.delete(cno, request);
			msg = "삭제 성공";
			msg = URLEncoder.encode(msg,"UTF-8");
			day = URLEncoder.encode(day, "UTF-8");
			if(pageno==0) pageno=1;
		} catch (Exception e) {
			e.printStackTrace();
			throw new CacheException("찜 식품 삭제 중 오류 발생");
		}
		return "redirect:expect.do?msg="+msg+"&pageNumber="+pageno+"&day="+day;
	}
	
	// 추가로 추가된 내 섭취 정보 삭제 기능
	@GetMapping("deletediet.do")
	private String deletediet(HttpServletRequest request) {
		int pageno = Integer.parseInt(request.getParameter("pageNumber"));
		int dno  = Integer.parseInt(request.getParameter("dno"));
		String day = request.getParameter("day");
		String msg = "";
		try {
			mydietService.delete(dno, request);
			msg = "삭제 성공";
			msg = URLEncoder.encode(msg,"UTF-8");
			day = URLEncoder.encode(day, "UTF-8");
			if(pageno==0) pageno=1;
		} catch (Exception e) {
			e.printStackTrace();
			throw new CacheException("추가 식품 삭제 중 오류 발생");
		}
		return "redirect:myeat.do?msg="+msg+"&pageNumber="+pageno+"&day="+day;
	}
	
	// 예상 섭취 정보 출력 기능
	@GetMapping("expect.do")
	private String expect(HttpServletRequest request, HttpServletResponse response) {
		String id = getId(request);
		System.out.println("아이디가 누구냐 : "+id);
		String msg = request.getParameter("msg");
		String day = request.getParameter("day");
		request.setAttribute("msg", msg);
		
		String pageNo = request.getParameter("pageNumber");
		int pno = Integer.parseInt(pageNo);
		request.setAttribute("pageNumber",pageNo);
		
		PageBean bean = new PageBean(pageNo);
		int interval = bean.getInterval();
		
		List<MyDiet> tmp = null;
		List<Cart> carts = null;
		if(day.equals("1")) {
			tmp = mydietService.week(id);
			carts = cartService.week(id);
		}else if(day.equals("2")) {
			tmp = mydietService.month(id);
			carts = cartService.month(id);
		}else if(day.equals("3")){
			tmp = mydietService.year(id);
			carts = cartService.year(id);
		}else {
			tmp = mydietService.search(id);
			carts = cartService.search(id);
		}
		
		//1-1.영양정보별로 더해서 리스트	섭취 영양성분
		int[] eat = new int[10];
		for(int i=0; i<tmp.size(); i++) {
			MyDiet md = tmp.get(i);
			Food f = md.getFood();
			int amnt = md.getAmount();
			eat[0] += f.getSupportpereat()*amnt;
			eat[1] += f.getCalory()*amnt;
			eat[2] += f.getCarbo()*amnt;
			eat[3] += f.getProtein()*amnt;
			eat[4] += f.getFat()*amnt;
			eat[5] += f.getSugar()*amnt;
			eat[6] += f.getNatrium()*amnt;
			eat[7] += f.getChole()*amnt;
			eat[8] += f.getFattyacid()*amnt;
			eat[9] += f.getTransfat()*amnt;
		}
//		for (int i = 0; i < eat.length; i++) {
//			eat[i] = Double.parseDouble(String.format("%.1f", eat[i]));
//		}
		//1-2.영양정보별로 더해서 리스트	예상 섭취 영양성분
		int[] nut = new int[10];
		for(int i=0; i<carts.size(); i++) {
			Cart ct = carts.get(i);
			Food f = ct.getFood();
			int amnt = ct.getAmount();
			nut[0] += f.getSupportpereat()*amnt;
			nut[1] += f.getCalory()*amnt;
			nut[2] += f.getCarbo()*amnt;
			nut[3] += f.getProtein()*amnt;
			nut[4] += f.getFat()*amnt;
			nut[5] += f.getSugar()*amnt;
			nut[6] += f.getNatrium()*amnt;
			nut[7] += f.getChole()*amnt;
			nut[8] += f.getFattyacid()*amnt;
			nut[9] += f.getTransfat()*amnt;
		}
		
		List<TotalDiet> tod = mydietService.total(id);
		
		//2. 이름별, 수량 더해서 리스트		섭취 내역
		List<String[]> arr = new ArrayList<>(interval);
		
		int size = (pno-1)*interval + interval;
		int index = 0;
		for (int i = (pno-1)*interval ; i < size; i++) {
			if(i==tod.size()) break;
			TotalDiet tmpDiet = tod.get(i);
			arr.add(index++,new String[] {tmpDiet.getName(),tmpDiet.getAmount()});
		}
        
		int total = tod.size();
		PageUtility bar = new PageUtility(bean.getInterval()
				, total, bean.getPageNo(), "images/");
		bean.setPageLink(bar.getPageBar());
		
		request.setAttribute("bean",bean);
		
		request.setAttribute("n1", nut);
		request.setAttribute("e1", eat);
		request.setAttribute("n2", arr);
		request.setAttribute("n3", carts);
		request.setAttribute("day", day);
		return "cart";
	}
	
	// 내 섭취 정보 출력 기능
	@GetMapping("myeat.do")
	private String myeat(HttpServletRequest request, HttpServletResponse response) {
		String id = getId(request);
		String msg = request.getParameter("msg");
		String day = request.getParameter("day");
		request.setAttribute("msg", msg);
		
		String pageNo = request.getParameter("pageNumber");
		int pno = Integer.parseInt(pageNo);
		request.setAttribute("pageNumber",pageNo);
		
		PageBean bean = new PageBean(pageNo);
		int interval = bean.getInterval();
		
		List<MyDiet> tmp = null;
		if(day.equals("1")) {
			tmp = mydietService.week(id);
		}else if(day.equals("2")) {
			tmp = mydietService.month(id);
		}else if(day.equals("3")){
			tmp = mydietService.year(id);
		}else {
			tmp = mydietService.search(id);
		}
		ArrayList<MyDiet> diets = new ArrayList<>(interval);
		int size = (pno-1)*interval + interval;
		for (int i = (pno-1)*interval; i < size; i++) {
			if(i==tmp.size()) break;
			diets.add(tmp.get(i));
		}
		for (MyDiet myDiet : diets) {
			System.out.println(myDiet.toString());
		}
		
		int total = tmp.size();
		PageUtility bar = new PageUtility(bean.getInterval()
				, total, bean.getPageNo(), "images/");
		bean.setPageLink(bar.getPageBar());
		
		request.setAttribute("bean",bean);
		//1-1.영양정보별로 더해서 리스트	섭취 영양성분
		int[] eat = new int[10];
		for(int i=0; i<tmp.size(); i++) {
			MyDiet md = tmp.get(i);
			Food f = md.getFood();
			int amnt = md.getAmount();
			eat[0] += f.getSupportpereat()*amnt;
			eat[1] += f.getCalory()*amnt;
			eat[2] += f.getCarbo()*amnt;
			eat[3] += f.getProtein()*amnt;
			eat[4] += f.getFat()*amnt;
			eat[5] += f.getSugar()*amnt;
			eat[6] += f.getNatrium()*amnt;
			eat[7] += f.getChole()*amnt;
			eat[8] += f.getFattyacid()*amnt;
			eat[9] += f.getTransfat();
		}
//		for (int i = 0; i < eat.length; i++) {
//			eat[i] = Double.parseDouble(String.format("%.1f", eat[i]));
//		}
		
		
		List<TotalDiet> tod = mydietService.total(id);
		
		//2. 이름별, 수량 더해서 리스트		섭취 내역
		
		List<String[]> arr = new LinkedList<>();
		int index = 0;
		for (int i = 0; i < tod.size(); i++) {
			TotalDiet tmpDiet = tod.get(i);
			arr.add(index++, new String[] {tmpDiet.getName(),tmpDiet.getAmount()});
		}

		request.setAttribute("e1", eat);
		request.setAttribute("n2", arr);
		request.setAttribute("n3", diets);
		request.setAttribute("day", day);
		return "myeat";
	}
	
	// 관리자 전용 회원 관리 폼 이동
	@GetMapping("adminmem.do")
	private String adminmem(HttpServletRequest request) {
		List<Member> list = memberService.searchAll();
		request.setAttribute("list", list);
		return "manage_mem";
	}
	
	// 관리자 전용 회원 관리 삭제 기능
	@GetMapping("delmem.do")
	private String deletemem(HttpServletRequest request) {
		String id = request.getParameter("id");
		if(id!=null) memberService.delete(id);
		return "redirect:adminmem.do";
	}
	
	// 로그인 기능 ( 아이디 및 비밀번호 확인 후 로그인 처리 )
	@PostMapping("login.do")
	private String login(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String idsave = request.getParameter("idsave");
		String referer = request.getParameter("referer");

		Cookie cookie = new Cookie("id", id);
		if (idsave != null) {
			cookie.setMaxAge(10000000);
		} else {
			cookie.setMaxAge(0);
		}
		response.addCookie(cookie);
		try {
			memberService.login(id, pw);
			addToSession(request, "id", id);
			if (referer != null) {
				return referer;
			} else {
				return "redirect:index.do";
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", e.getMessage());
			return "login";
		}
	}

	// 비밀번호 찾기 찾기 기능
	@PostMapping("findpassword.do")
	private String findpw(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		try {
			Member member = memberService.search(id);
			if (member != null) {
				request.setAttribute("findpw", member);
				return "findPassword";
			} else {
				return "findPasswordForm.do";
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", e.getMessage());
			return "findPassword";
		}
	}
	
	// 검색창 기능
	@PostMapping("search.do")
	private String searchAllFood(HttpServletRequest request, HttpServletResponse response) {
		String option = request.getParameter("droplist");
		String searchbar = request.getParameter("searchbar");
		List<Food> list = null;

		request.setAttribute("droplist", option);
		request.setAttribute("searchbar", searchbar);
		if (option.equals("1")) {
			list = foodService.searchAllName(searchbar);
		} else if (option.equals("2")) {
			list = foodService.searchAllMaker(searchbar);
		} else if (option.equals("3")) {
			list = foodService.searchAllMaterial(searchbar);
		} else {
			list = foodService.searchAll();
		}
		Collections.sort(list);
		request.setAttribute("list", list);
		return "index";
	}
	
	// 상품 목록을 불러오는 초기화면 
	@GetMapping("index.do")
	private String listFood(HttpServletRequest request, HttpServletResponse response) {
		
		List<Food> list = foodService.searchAll();
		System.out.println(list);
		Collections.sort(list);

		request.setAttribute("list", list);
		return "index";
	}
	
	
	// 상품 정보에서 추가기능, 추가 버튼 ( 내 섭취 정보 )
	@PostMapping("addmydiet.do")
	private String addCart(HttpServletRequest request, HttpServletResponse response) {

		String amount = request.getParameter("cnt"); //추가 수량 가져오기
		SimpleDateFormat format = new SimpleDateFormat ( "yyyy-MM-dd HH:mm:ss");
		Date time = new Date();
		String current = format.format(time);
		
		MyDiet mydiet = new MyDiet();
		String code = request.getParameter("Fcode");
		String msg="";
		String id = getId(request);
		int cnt = Integer.parseInt(amount);
		
		if(id==null) {
			msg = "로그인을 해주세요.";
		}else if(cnt>0 && code != null && current != null && id != null) {
			mydiet.setCode(code);
			mydiet.setRegdate(current);
			mydiet.setAmount(cnt);
			mydiet.setId(id);
			mydietService.insert(mydiet, request); //추가하기
			msg = "성공적으로  추가 되었습니다.";
		}else {
			msg = "추가 중 오류가 발생하였습니다.";
		}
		
		try {
			msg = URLEncoder.encode(msg,"UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
			throw new CacheException("메세지 인코딩 중 오류 발생");
		}
		return "redirect:detailform.do?code="+code+"&msg="+msg;
	}
	
	
	//상품 정보에서 카트 추가 , 찜버튼 ( 예상 섭취 정보 ) 
	@PostMapping("addcart.do")
	private String addMydiet(HttpServletRequest request, HttpServletResponse response) {
		
		String amount = request.getParameter("cnt"); //추가 수량 가져오기
		SimpleDateFormat format = new SimpleDateFormat ( "yyyy-MM-dd HH:mm:ss");
		Date time = new Date();
		String current = format.format(time);
		
		Cart cart = new Cart();
		String code = request.getParameter("Fcode");
		String msg ="";
		String id = getId(request);
		int cnt = Integer.parseInt(amount);
		
		if(id==null) {
			msg = "로그인을 해주세요.";
		}else if(cnt>0 && code != null && current != null && id != null) {
			cart.setCode(code);
			cart.setRegdate(current);
			cart.setAmount(cnt);
			cart.setId(id);
			cartService.insert(cart, request); //추가하기
			msg ="성공적으로  추가 되었습니다.";
		}else {
			msg= "추가 중 오류가 발생하였습니다.";
		}
		
		
		try {
			msg = URLEncoder.encode(msg,"UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
			throw new CacheException("메세지 인코딩 중 오류 발생");
		}
		
		return "redirect:detailform.do?code="+code+"&msg="+msg;
	}
	

	public void addToSession(HttpServletRequest request, String key, Object value) {
		HttpSession session = request.getSession();
		session.setAttribute(key, value);
	}

	public String getId(HttpServletRequest request) {
		HttpSession session = request.getSession();
		return (String) session.getAttribute("id");
	}

	public ResponseEntity<Map<String, Object>> handleSuccess(Object data) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state", "ok");
		resultMap.put("data", data);
		return new ResponseEntity<Map<String, Object>>(resultMap, HttpStatus.OK);
	}

	public ResponseEntity<Map<String, Object>> handleFail(Object data, HttpStatus status) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("state", "fail");
		resultMap.put("data", data);
		return new ResponseEntity<Map<String, Object>>(resultMap, status);
	}
}
