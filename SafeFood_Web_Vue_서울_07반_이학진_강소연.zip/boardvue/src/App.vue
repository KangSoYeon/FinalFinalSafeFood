<template>
  <div id="page-top">
    <nav>
      <router-link to="/safefood/qna.do"></router-link>
    </nav>
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  name: 'app'
}
</script>

<style scoped>

</style>
