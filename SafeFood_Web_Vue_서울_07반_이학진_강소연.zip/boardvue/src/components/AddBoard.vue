<template>
    <div>
        <form method="post" @submit.prevent="addboard" >
        <table class="list_table">
            <th colspan="2"> 게시글 </th>
            <tbody>
                <tr height="50"><td><label for="title">제목</label></td>
                    <td><input style="width:100%" v-model="title" type="text" name="title" id="title"/></td>
                </tr>
                <tr height="50"><td><label for="title">아이디</label></td>
                <td><input style="width:100%" v-model="id" type="text" name="id" id="id"/></td>
                </tr>
                <tr><td colspan="2"><label for="content">내용</label></td></tr>
                <tr><td colspan="2" align="center">
                    <textarea style="width:100%" v-model="content" name="contents" id="content" cols="30" rows="10"></textarea>
                </td></tr>
            </tbody>
            <tfoot>
                <tr><td colspan="2" align="center">
                    <button type="submit">작성</button>
                    <button @click="returnlist">취소</button>
                </td></tr>
            </tfoot>
        </table>
        </form>
    </div>
</template>

<script>
    import http from '../http-commom'
    export default {
        name:'add-board',
        data() {
            return{
                id:'',
                loading: true,
                errored: false,                
                title:'',
                content:''
            }
        },
        methods: {
            returnlist(){
                this.$router.push('/safefood/qna.do')
            }
            ,
            addboard(){
                if(this.title=='') {
                    alert('제목을 입력하세요');
                    return false;
                }
                if(this.content=='') {
                    alert('내용을 입력하세요');
                    return false;
                }
                if(this.id=='') {
                    alert('아이디를 입력하세요')
                }
                http
                .post('',{
                    "id":this.id,
                    "title":this.title,
                    "content":this.content
                })
                .then(response=>{
                    if(response.data.state=='succ'){
                        alert('게시물 등록 성공')
                        this.$router.push('/safefood/qna.do')
                    }
                })
                .catch(()=>{
                    alert('게시물 등록 실패')
                    this.errored = true;
                })
                .finally(()=>{
                    this.loading = false;
                })
                
            }   
        }
    }
</script>

<style scoped>
    
</style>