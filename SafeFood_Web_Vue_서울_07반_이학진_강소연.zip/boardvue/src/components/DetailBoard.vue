<template>
    <div>
        <table class="list_table">
            <th colspan="2"> 게시글 </th>
            <tbody>
                <tr height="50"><td><label for="title">제목</label></td>
                    <td><input style="width:100%" v-model="board.title" type="text" name="title" id="title"/></td>
                </tr>
                <tr height="50"><td><label for="title">아이디</label></td>
                <td><input style="width:100%" v-model="board.id" type="text" name="id" id="id"/></td>
                </tr>
                <tr><td colspan="2"><label for="content">내용</label></td></tr>
                <tr><td colspan="2" align="center">
                    <textarea style="width:100%" v-model="board.contents" name="contents" id="content" cols="30" rows="10"></textarea>
                </td></tr>
            </tbody>
            <tfoot>
                <tr><td colspan="2" align="center">
                    <button @click="modifyboard">수정</button>
                    <button @click="deleteboard(board.no)">삭제</button>
                    <button @click="returnlist">취소</button>
                </td></tr>
            </tfoot>
        </table>
    </div>
</template>

<script>
    import http from '../http-commom'
    import bus from '../eventBus'
    export default {
        name: 'detail-board',
        data() {
            return{
                loading:true,
                errored:false,
                board:{}
            }
        },
        created () {
            bus.$on('no',this.searchBoard);
        },
        methods: {
            searchBoard(no){
                http
                .get('/boardSearch/'+no)
                .then(response=>{
                    this.board = response.data.data
                })
                .catch(()=>{
                    alert('게시물 조회 중 오류 발생')
                    this.errored = true
                })
                .finally(()=>{
                    this.loading=false
                })
            },
            modifyboard() {
                if(this.board.title==''){
                    alert('제목을 입력하세요')
                    return false;
                }
                if(this.board.id==''){
                    alert('아이디을 입력하세요')
                    return false;
                }
                if(this.board.contents==''){
                    alert('내용을 입력하세요')
                    return false;
                }
                http
                .put('/updateBoard',{
                    "contents": this.board.contents,
                    "id": this.board.id,
                    "no": this.board.no,
                    "regdate": this.board.regdate,
                    "reply": this.board.reply,
                    "title": this.board.title
                })
                .then(response=>{
                    if(response.data.state=='ok'){
                        alert('수정 성공')
                        this.$router.push('/safefood/qna.do')
                    }
                })
                .catch(()=>{
                    alert('게시물 수정 중 오류 발생')
                    this.errored = true;
                })
                .finally(()=>{this.loading=false})
            },
            deleteboard(no) {
                http
                .delete('/deleteBoard/'+no)
                .then(response=>{
                    if(response.data.state=='ok'){
                        alert('삭제 성공')
                        this.$router.push('/safefood/qna.do')
                    }
                })
                .catch(()=>{
                    alert('게시물 삭제 중 오류 발생')
                    this.errored = true;
                })
                .finally(()=>{this.loading=false})
            },
            returnlist(){
                this.$router.push('/safefood/qna.do')
            }
        }
    }
</script>

<style scoped>

</style>